<?php
function vidiho_pro_plugin_sanitize_metabox_tab_sidebar( $post_id ) {
	// Ignore phpcs issues. nonce validation happens inside vidiho_pro_plugin_can_save_meta(), from the caller of this function.
	// @codingStandardsIgnoreStart
	update_post_meta( $post_id, 'vidiho_pro_sidebar', vidiho_pro_plugin_sanitize_sidebar( $_POST['vidiho_pro_sidebar'] ) );
	// @codingStandardsIgnoreEnd
}

function vidiho_pro_plugin_print_metabox_tab_sidebar( $object, $box ) {

	vidiho_pro_plugin_metabox_open_tab( esc_html__( 'Sidebar', 'vidiho-pro-plugin' ) );

		$options = vidiho_pro_plugin_get_sidebar_choices();
		foreach ( $options as $key => $value ) {
			vidiho_pro_plugin_metabox_radio( 'vidiho_pro_sidebar', "sidebar-$key", $key, $value, array( 'default' => apply_filters( 'vidiho_pro_plugin_sanitize_sidebar_default', 'right' ) ) );
		}

	vidiho_pro_plugin_metabox_close_tab();
}

function vidiho_pro_plugin_get_sidebar_choices() {
	return apply_filters( 'vidiho_pro_plugin_sidebar_choices', array(
		'left'  => esc_html__( 'Left sidebar', 'vidiho-pro-plugin' ),
		'right' => esc_html__( 'Right sidebar', 'vidiho-pro-plugin' ),
		'none'  => esc_html__( 'No sidebar', 'vidiho-pro-plugin' ),
	) );
}

function vidiho_pro_plugin_sanitize_sidebar( $value ) {
	$choices = vidiho_pro_plugin_get_sidebar_choices();
	if ( array_key_exists( $value, $choices ) ) {
		return $value;
	}

	return apply_filters( 'vidiho_pro_plugin_sanitize_sidebar_default', 'right' );
}
