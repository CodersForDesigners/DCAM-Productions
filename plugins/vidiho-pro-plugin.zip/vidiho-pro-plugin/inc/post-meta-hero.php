<?php
function vidiho_pro_plugin_sanitize_metabox_tab_hero( $post_id ) {
	// Ignore phpcs issues. nonce validation happens inside vidiho_pro_plugin_can_save_meta(), from the caller of this function.
	// @codingStandardsIgnoreStart

	$support = get_theme_support( 'vidiho-pro-hero' );
	$support = $support[0];
	if ( ! $support['required'] ) {
		update_post_meta( $post_id, 'hero_show', isset( $_POST['hero_show'] ) ? 1 : 0 );
	}

	update_post_meta( $post_id, 'hero_text_align', vidiho_pro_plugin_sanitize_text_align( $_POST['hero_text_align'] ) );
	update_post_meta( $post_id, 'page_title_hide', isset( $_POST['page_title_hide'] ) ? 1 : 0 );

	update_post_meta( $post_id, 'hero_image_id', vidiho_pro_plugin_sanitize_intval_or_empty( $_POST['hero_image_id'] ) );
	update_post_meta( $post_id, 'hero_bg_color', sanitize_hex_color( $_POST['hero_bg_color'] ) );
	update_post_meta( $post_id, 'hero_bg_hover_color', sanitize_hex_color( $_POST['hero_bg_hover_color'] ) );
	update_post_meta( $post_id, 'hero_text_color', sanitize_hex_color( $_POST['hero_text_color'] ) );
	update_post_meta( $post_id, 'hero_overlay_color', vidiho_pro_plugin_sanitize_rgba_color( $_POST['hero_overlay_color'] ) );
	update_post_meta( $post_id, 'hero_image_repeat', vidiho_pro_plugin_sanitize_image_repeat( $_POST['hero_image_repeat'] ) );
	update_post_meta( $post_id, 'hero_image_position_x', vidiho_pro_plugin_sanitize_image_position_x( $_POST['hero_image_position_x'] ) );
	update_post_meta( $post_id, 'hero_image_position_y', vidiho_pro_plugin_sanitize_image_position_y( $_POST['hero_image_position_y'] ) );
	update_post_meta( $post_id, 'hero_image_attachment', vidiho_pro_plugin_sanitize_image_attachment( $_POST['hero_image_attachment'] ) );
	update_post_meta( $post_id, 'hero_image_cover', isset( $_POST['hero_image_cover'] ) ? 1 : 0 );
	// @codingStandardsIgnoreEnd
}

function vidiho_pro_plugin_print_metabox_tab_hero( $object, $box ) {
	$support = get_theme_support( 'vidiho-pro-hero' );
	$support = $support[0];

	$page_title_hide_default    = $support['required'] || $support['show-default'] ? 1 : 0;
	$page_title_hide_guide_text = __( 'Since the hero section shows the title by default, you may want to disable the page title (shown before the content).', 'vidiho-pro-plugin' );

	if ( 'post' === get_post_type( $object->ID ) ) {
		$page_title_hide_default = 0;
		/* translators: %s is a user-provided title. */
		$page_title_hide_guide_text = sprintf( __( 'When checked, the title will appear on the hero section, replacing the blog title you have set from <em>Customize &rarr; Titles &rarr; General &rarr; Blog title</em>, currently set to: <em>%s</em>.', 'vidiho-pro-plugin' ), get_theme_mod( 'title_blog', __( 'From the blog', 'vidiho-pro-plugin' ) ) );
	}

	$page_title_hide_default    = apply_filters( 'vidiho_pro_hero_page_title_hide_default', $page_title_hide_default, get_post_type( $object->ID ), $object->ID );
	$page_title_hide_guide_text = apply_filters( 'vidiho_pro_hero_page_title_hide_guide_text', $page_title_hide_guide_text, get_post_type( $object->ID ), $object->ID, $page_title_hide_default );

	vidiho_pro_plugin_metabox_open_tab( esc_html__( 'Hero section', 'vidiho-pro-plugin' ) );

		if ( ! $support['required'] ) {
			vidiho_pro_plugin_metabox_checkbox( 'hero_show', 1, esc_html__( 'Show hero section.', 'vidiho-pro-plugin' ), array( 'default' => intval( $support['show-default'] ) ) );
		}

		vidiho_pro_plugin_metabox_dropdown( 'hero_text_align', vidiho_pro_plugin_get_text_align_choices(), esc_html__( 'Title / subtitle alignment:', 'vidiho-pro-plugin' ), array( 'default' => $support['text-align'] ) );

		vidiho_pro_plugin_metabox_guide( wp_kses( $page_title_hide_guide_text, vidiho_pro_plugin_get_allowed_tags( 'guide' ) ) );
		vidiho_pro_plugin_metabox_checkbox( 'page_title_hide', 1, esc_html__( 'Hide page title.', 'vidiho-pro-plugin' ), array( 'default' => $page_title_hide_default ) );

		?><p class="ci-field-group ci-field-input"><?php
			vidiho_pro_plugin_metabox_input( 'hero_bg_color', esc_html__( 'Background Color:', 'vidiho-pro-plugin' ), array( 'input_class' => 'vidiho-pro-color-picker widefat', 'before' => '', 'after' => '' ) );
		?></p><?php
		?><p class="ci-field-group ci-field-input vidiho-pro-show-on-front-page"><?php
			vidiho_pro_plugin_metabox_input( 'hero_bg_hover_color', esc_html__( 'Background Color on Hover:', 'vidiho-pro-plugin' ), array( 'input_class' => 'vidiho-pro-color-picker widefat', 'before' => '', 'after' => '' ) );
		?></p><?php
		?><p class="ci-field-group ci-field-input"><?php
			vidiho_pro_plugin_metabox_input( 'hero_text_color', esc_html__( 'Text Color:', 'vidiho-pro-plugin' ), array( 'input_class' => 'vidiho-pro-color-picker widefat', 'before' => '', 'after' => '' ) );
		?></p><?php
		?><p class="ci-field-group ci-field-input"><?php
			vidiho_pro_plugin_metabox_input( 'hero_overlay_color', esc_html__( 'Overlay Color:', 'vidiho-pro-plugin' ), array( 'input_class' => 'vidiho-pro-alpha-color-picker widefat', 'before' => '', 'after' => '' ) );
		?></p><?php


		?><div class="vidiho-pro-hide-on-front-page"><?php
			vidiho_pro_plugin_metabox_guide( array(
				wp_kses( __( 'The following image options are only applicable when a Hero image is selected.', 'vidiho-pro-plugin' ), vidiho_pro_plugin_get_allowed_tags( 'guide' ) ),
			) );

			$hero_image_id = get_post_meta( $object->ID, 'hero_image_id', true );
			?>
			<div class="ci-field-group ci-field-input">
				<label for="header_image_id"><?php esc_html_e( 'Hero image:', 'vidiho-pro-plugin' ); ?></label>
				<div class="ci-upload-preview">
					<div class="upload-preview">
						<?php if ( ! empty( $hero_image_id ) ) : ?>
							<?php
								$image_url = wp_get_attachment_image_url( $hero_image_id, 'vidiho_pro_plugin_featgal_small_thumb' );
								echo sprintf( '<img src="%s" /><a href="#" class="close media-modal-icon" title="%s"></a>',
									esc_url( $image_url ),
									esc_attr__( 'Remove image', 'vidiho-pro-plugin' )
								);
							?>
						<?php endif; ?>
					</div>
					<input name="hero_image_id" type="hidden" class="ci-uploaded-id" value="<?php echo esc_attr( $hero_image_id ); ?>" />
					<input id="hero_image_id" type="button" class="button ci-media-button" value="<?php esc_attr_e( 'Select Image', 'vidiho-pro-plugin' ); ?>" />
				</div>
			</div>
			<?php

			vidiho_pro_plugin_metabox_dropdown( 'hero_image_repeat', vidiho_pro_plugin_get_image_repeat_choices(), esc_html__( 'Image repeat:', 'vidiho-pro-plugin' ), array( 'default' => 'no-repeat' ) );
			vidiho_pro_plugin_metabox_dropdown( 'hero_image_position_x', vidiho_pro_plugin_get_image_position_x_choices(), esc_html__( 'Image horizontal position:', 'vidiho-pro-plugin' ), array( 'default' => 'center' ) );
			vidiho_pro_plugin_metabox_dropdown( 'hero_image_position_y', vidiho_pro_plugin_get_image_position_y_choices(), esc_html__( 'Image vertical position:', 'vidiho-pro-plugin' ), array( 'default' => 'center' ) );
			vidiho_pro_plugin_metabox_dropdown( 'hero_image_attachment', vidiho_pro_plugin_get_image_attachment_choices(), esc_html__( 'Image attachment:', 'vidiho-pro-plugin' ), array( 'default' => 'scroll' ) );
			vidiho_pro_plugin_metabox_checkbox( 'hero_image_cover', 1, esc_html__( 'Scale the image to cover its container.', 'vidiho-pro-plugin' ), array( 'default' => 1 ) );
		?></div><?php

	vidiho_pro_plugin_metabox_close_tab();
}
