<?php
/*
Plugin Name: Vidiho Pro Essentials
Description: Features required by the Vidiho Pro theme.
Plugin URI: https://www.cssigniter.com/themes/vidiho-pro/
Version: 1.0
License: GNU General Public License v2 or later
Author: The CSSIgniter Team
Author URI: https://www.cssigniter.com/
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: vidiho-pro-plugin
*/

if ( ! defined( 'VIDIHO_PRO_PLUGIN_VERSION' ) ) {
	define( 'VIDIHO_PRO_PLUGIN_VERSION', '1.0' );
}

if ( ! defined( 'VIDIHO_PRO_PLUGIN_DIR' ) ) {
	define( 'VIDIHO_PRO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'VIDIHO_PRO_PLUGIN_DIR_URL' ) ) {
	define( 'VIDIHO_PRO_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
}

add_action( 'after_setup_theme', 'vidiho_pro_plugin_setup' );
function vidiho_pro_plugin_setup() {
	load_plugin_textdomain( 'vidiho-pro-plugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	// Automatic thumbnails for video posts.
	add_action( 'save_post', 'vidiho_pro_plugin_save_video_thumbnail' );
	add_action( 'wp_insert_post', 'vidiho_pro_plugin_save_video_thumbnail' );
	add_filter( 'vidiho_pro_plugin_automatic_video_thumbnail_field', 'vidiho_pro_plugin_automatic_video_thumbnail_field' );
	add_filter( 'vidiho_pro_plugin_automatic_video_thumbnail_target_field_id', 'vidiho_pro_plugin_automatic_video_thumbnail_target_field_id' );
}

/**
 * Enqueue admin scripts and styles.
 */
function vidiho_pro_plugin_admin_scripts( $hook ) {

	if ( ! wp_script_is( 'alpha-color-picker', 'enqueued' ) && ! wp_script_is( 'alpha-color-picker', 'registered' ) ) {
		wp_register_style( 'alpha-color-picker', untrailingslashit( VIDIHO_PRO_PLUGIN_DIR_URL ) . '/assets/vendor/alpha-color-picker/alpha-color-picker.css', array(
			'wp-color-picker',
		), '1.0.0' );
		wp_register_script( 'alpha-color-picker', untrailingslashit( VIDIHO_PRO_PLUGIN_DIR_URL ) . '/assets/vendor/alpha-color-picker/alpha-color-picker.js', array(
			'jquery',
			'wp-color-picker',
		), '1.0.0', true );
	}

	wp_register_style( 'vidiho-pro-plugin-post-meta', untrailingslashit( VIDIHO_PRO_PLUGIN_DIR_URL ) . '/assets/css/post-meta.css', array(
		'alpha-color-picker',
	), VIDIHO_PRO_PLUGIN_VERSION );
	wp_register_script( 'vidiho-pro-plugin-post-meta', untrailingslashit( VIDIHO_PRO_PLUGIN_DIR_URL ) . '/assets/js/post-meta.js', array(
		'media-editor',
		'jquery',
		'jquery-ui-sortable',
		'alpha-color-picker',
	), VIDIHO_PRO_PLUGIN_VERSION, true );

	$settings = array(
		'ajaxurl'             => admin_url( 'admin-ajax.php' ),
		'tSelectFile'         => esc_html__( 'Select file', 'vidiho-pro-plugin' ),
		'tSelectFiles'        => esc_html__( 'Select files', 'vidiho-pro-plugin' ),
		'tUseThisFile'        => esc_html__( 'Use this file', 'vidiho-pro-plugin' ),
		'tUseTheseFiles'      => esc_html__( 'Use these files', 'vidiho-pro-plugin' ),
		'tUpdateGallery'      => esc_html__( 'Update gallery', 'vidiho-pro-plugin' ),
		'tLoading'            => esc_html__( 'Loading...', 'vidiho-pro-plugin' ),
		'tPreviewUnavailable' => esc_html__( 'Gallery preview not available.', 'vidiho-pro-plugin' ),
		'tRemoveImage'        => esc_html__( 'Remove image', 'vidiho-pro-plugin' ),
		'tRemoveFromGallery'  => esc_html__( 'Remove from gallery', 'vidiho-pro-plugin' ),
	);
	wp_localize_script( 'vidiho-pro-plugin-post-meta', 'vidiho_pro_plugin_PostMeta', $settings );


	//
	// Enqueue
	//
	if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_media();
		wp_enqueue_style( 'vidiho-pro-plugin-post-meta' );
		wp_enqueue_script( 'vidiho-pro-plugin-post-meta' );
	}

}
add_action( 'admin_enqueue_scripts', 'vidiho_pro_plugin_admin_scripts' );


function vidiho_pro_plugin_get_columns_classes( $columns ) {
	if ( function_exists( 'vidiho_pro_get_columns_classes' ) ) {
		return vidiho_pro_get_columns_classes( $columns );
	}

	switch ( intval( $columns ) ) {
		case 1:
			$classes = 'col-12';
			break;
		case 2:
			$classes = 'col-sm-6 col-12';
			break;
		case 3:
			$classes = 'col-lg-4 col-sm-6 col-12';
			break;
		case 4:
		default:
			$classes = 'col-xl-3 col-lg-4 col-sm-6 col-12';
			break;
	}

	// Filter name intentionally same to vidiho_pro_get_columns_classes()
	return apply_filters( 'vidiho_pro_get_columns_classes', $classes, $columns );
}


function vidiho_pro_plugin_automatic_video_thumbnail_field( $field ) {
	return 'vidiho_pro_video_url';
}

function vidiho_pro_plugin_automatic_video_thumbnail_target_field_id( $field ) {
	return 'vidiho_pro_video_thumbnail_id';
}

function vidiho_pro_plugin_get_video_layout_choices() {
	return apply_filters( 'vidiho_pro_plugin_video_layout_choices', array(
		''     => esc_html__( 'Video info on content', 'vidiho-pro-plugin' ),
		'hero' => esc_html__( 'Video info on hero', 'vidiho-pro-plugin' ),
	) );
}

function vidiho_pro_plugin_sanitize_video_layout( $value ) {
	$choices = vidiho_pro_plugin_get_video_layout_choices();
	if ( array_key_exists( $value, $choices ) ) {
		return $value;
	}

	return apply_filters( 'vidiho_pro_plugin_sanitize_video_layout_default', '' );
}


function vidiho_pro_plugin_activated() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	vidiho_pro_plugin_create_cpt_video();

	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'vidiho_pro_plugin_activated' );

function vidiho_pro_plugin_deactivated() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	unregister_post_type( 'vidiho_pro_video' );
	unregister_taxonomy( 'vidiho_pro_video_category' );

	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'vidiho_pro_plugin_deactivated' );



/**
 * Custom fields / post types / taxonomies.
 */
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/custom-fields-post.php';
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/custom-fields-page.php';
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/custom-fields-video.php';


/**
 * Standard helper functions.
 */
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/inc/helpers.php';

/**
 * Standard sanitization functions.
 */
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/inc/sanitization.php';

/**
 * Post meta helpers.
 */
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/inc/post-meta.php';
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/inc/post-meta-title-subtitle.php';
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/inc/post-meta-hero.php';
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/inc/post-meta-sidebar.php';

/**
 * Post types listing related functions.
 */
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/inc/items-listing.php';

/**
 * User fields.
 */
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/user-meta.php';

/**
 * Shortcodes.
 */
require untrailingslashit( VIDIHO_PRO_PLUGIN_DIR ) . '/shortcodes.php';
