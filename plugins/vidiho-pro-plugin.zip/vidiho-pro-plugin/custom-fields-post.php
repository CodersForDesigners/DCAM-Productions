<?php
add_action( 'admin_init', 'vidiho_pro_plugin_cpt_post_add_metaboxes' );
add_action( 'save_post', 'vidiho_pro_plugin_cpt_post_update_meta' );

if ( ! function_exists( 'vidiho_pro_plugin_cpt_post_add_metaboxes' ) ) :
	function vidiho_pro_plugin_cpt_post_add_metaboxes() {
		add_meta_box( 'vidiho-pro-plugin-hero', esc_html__( 'Hero section', 'vidiho-pro-plugin' ), 'vidiho_pro_plugin_add_post_hero_meta_box', 'post', 'normal', 'high' );
		add_meta_box( 'vidiho-pro-plugin-sidebar', esc_html__( 'Sidebar', 'vidiho-pro-plugin' ), 'vidiho_pro_plugin_add_post_sidebar_meta_box', 'post', 'side', 'low' );
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_cpt_post_update_meta' ) ) :
	function vidiho_pro_plugin_cpt_post_update_meta( $post_id ) {

		if ( ! vidiho_pro_plugin_can_save_meta( 'post' ) ) {
			return;
		}

		vidiho_pro_plugin_sanitize_metabox_tab_sub_title( $post_id );

		vidiho_pro_plugin_sanitize_metabox_tab_hero( $post_id );

		vidiho_pro_plugin_sanitize_metabox_tab_sidebar( $post_id );

		update_post_meta( $post_id, 'home_slider', isset( $_POST['home_slider'] ) ? 1 : 0 );
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_add_post_hero_meta_box' ) ) :
	function vidiho_pro_plugin_add_post_hero_meta_box( $object, $box ) {
		vidiho_pro_plugin_prepare_metabox( 'post' );

		?><div class="ci-cf-wrap"><?php

			vidiho_pro_plugin_print_metabox_tab_sub_title( $object, $box );

			vidiho_pro_plugin_print_metabox_tab_hero( $object, $box );

			vidiho_pro_plugin_metabox_open_tab( esc_html__( 'Homepage Slider', 'vidiho-pro-plugin' ) );
				vidiho_pro_plugin_metabox_checkbox( 'home_slider', 1, esc_html__( 'Show this post on the homepage slider.', 'vidiho-pro-plugin' ) );
			vidiho_pro_plugin_metabox_close_tab();

		?></div><?php
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_add_post_sidebar_meta_box' ) ) :
	function vidiho_pro_plugin_add_post_sidebar_meta_box( $object, $box ) {
		vidiho_pro_plugin_prepare_metabox( 'post' );

		?><div class="ci-cf-wrap"><?php

			vidiho_pro_plugin_print_metabox_tab_sidebar( $object, $box );

		?></div><?php
	}
endif;
