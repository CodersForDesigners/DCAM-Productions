<?php
add_action( 'init', 'vidiho_pro_plugin_create_cpt_video' );

if ( ! function_exists( 'vidiho_pro_plugin_create_cpt_video' ) ) :
	function vidiho_pro_plugin_create_cpt_video() {
		$labels = array(
			'name'               => esc_html_x( 'Videos', 'post type general name', 'vidiho-pro-plugin' ),
			'singular_name'      => esc_html_x( 'Video', 'post type singular name', 'vidiho-pro-plugin' ),
			'menu_name'          => esc_html_x( 'Videos', 'admin menu', 'vidiho-pro-plugin' ),
			'name_admin_bar'     => esc_html_x( 'Video', 'add new on admin bar', 'vidiho-pro-plugin' ),
			'add_new'            => esc_html_x( 'Add New', 'video', 'vidiho-pro-plugin' ),
			'add_new_item'       => esc_html__( 'Add New Video', 'vidiho-pro-plugin' ),
			'edit_item'          => esc_html__( 'Edit Video', 'vidiho-pro-plugin' ),
			'new_item'           => esc_html__( 'New Video', 'vidiho-pro-plugin' ),
			'view_item'          => esc_html__( 'View Video', 'vidiho-pro-plugin' ),
			'search_items'       => esc_html__( 'Search Videos', 'vidiho-pro-plugin' ),
			'not_found'          => esc_html__( 'No Videos found', 'vidiho-pro-plugin' ),
			'not_found_in_trash' => esc_html__( 'No Videos found in the trash', 'vidiho-pro-plugin' ),
			'parent_item_colon'  => esc_html__( 'Parent Video:', 'vidiho-pro-plugin' ),
		);

		$args = array(
			'labels'          => $labels,
			'singular_label'  => esc_html_x( 'Video', 'post type singular name', 'vidiho-pro-plugin' ),
			'public'          => true,
			'show_ui'         => true,
			'capability_type' => 'post',
			'hierarchical'    => false,
			'has_archive'     => false,
			'rewrite'         => array( 'slug' => esc_html_x( 'video', 'post type slug', 'vidiho-pro-plugin' ) ),
			'menu_position'   => 10,
			'supports'        => array( 'title', 'editor', 'thumbnail', 'comments' ),
			'menu_icon'       => 'dashicons-format-video',
		);

		register_post_type( 'vidiho_pro_video', $args );

		$labels = array(
			'name'              => esc_html_x( 'Video Categories', 'taxonomy general name', 'vidiho-pro-plugin' ),
			'singular_name'     => esc_html_x( 'Video Category', 'taxonomy singular name', 'vidiho-pro-plugin' ),
			'search_items'      => esc_html__( 'Search Video Categories', 'vidiho-pro-plugin' ),
			'all_items'         => esc_html__( 'All Video Categories', 'vidiho-pro-plugin' ),
			'parent_item'       => esc_html__( 'Parent Video Category', 'vidiho-pro-plugin' ),
			'parent_item_colon' => esc_html__( 'Parent Video Category:', 'vidiho-pro-plugin' ),
			'edit_item'         => esc_html__( 'Edit Video Category', 'vidiho-pro-plugin' ),
			'update_item'       => esc_html__( 'Update Video Category', 'vidiho-pro-plugin' ),
			'add_new_item'      => esc_html__( 'Add New Video Category', 'vidiho-pro-plugin' ),
			'new_item_name'     => esc_html__( 'New Video Category Name', 'vidiho-pro-plugin' ),
			'menu_name'         => esc_html__( 'Categories', 'vidiho-pro-plugin' ),
			'view_item'         => esc_html__( 'View Video Category', 'vidiho-pro-plugin' ),
			'popular_items'     => esc_html__( 'Popular Video Categories', 'vidiho-pro-plugin' ),
		);

		register_taxonomy( 'vidiho_pro_video_category', array( 'vidiho_pro_video' ), array(
			'labels'            => $labels,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => esc_html_x( 'video-category', 'taxonomy slug', 'vidiho-pro-plugin' ) ),
		) );
	}
endif;

add_action( 'admin_init', 'vidiho_pro_plugin_cpt_video_add_metaboxes' );
add_action( 'save_post', 'vidiho_pro_plugin_cpt_video_update_meta' );

if ( ! function_exists( 'vidiho_pro_plugin_cpt_video_add_metaboxes' ) ) :
	function vidiho_pro_plugin_cpt_video_add_metaboxes() {
		add_meta_box( 'vidiho-pro-plugin-hero', esc_html__( 'Hero section', 'vidiho-pro-plugin' ), 'vidiho_pro_plugin_add_video_hero_meta_box', 'vidiho_pro_video', 'normal', 'high' );
		add_meta_box( 'vidiho-pro-plugin-sidebar', esc_html__( 'Sidebar', 'vidiho-pro-plugin' ), 'vidiho_pro_plugin_add_video_sidebar_meta_box', 'vidiho_pro_video', 'side', 'low' );
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_cpt_video_update_meta' ) ) :
	function vidiho_pro_plugin_cpt_video_update_meta( $post_id ) {

		if ( ! vidiho_pro_plugin_can_save_meta( 'vidiho_pro_video' ) ) {
			return;
		}

		update_post_meta( $post_id, 'vidiho_pro_video_url', esc_url_raw( $_POST['vidiho_pro_video_url'] ) );
		update_post_meta( $post_id, 'vidiho_pro_video_thumbnail_id', vidiho_pro_plugin_sanitize_intval_or_empty( $_POST['vidiho_pro_video_thumbnail_id'] ) );
		update_post_meta( $post_id, 'vidiho_pro_video_layout', vidiho_pro_plugin_sanitize_video_layout( $_POST['vidiho_pro_video_layout'] ) );

		update_post_meta( $post_id, 'hero_show', 1 );

		update_post_meta( $post_id, 'hero_text_align', vidiho_pro_plugin_sanitize_text_align( $_POST['hero_text_align'] ) );

		update_post_meta( $post_id, 'hero_image_id', vidiho_pro_plugin_sanitize_intval_or_empty( $_POST['hero_image_id'] ) );
		update_post_meta( $post_id, 'hero_bg_color', sanitize_hex_color( $_POST['hero_bg_color'] ) );
		update_post_meta( $post_id, 'hero_text_color', sanitize_hex_color( $_POST['hero_text_color'] ) );
		update_post_meta( $post_id, 'hero_overlay_color', vidiho_pro_plugin_sanitize_rgba_color( $_POST['hero_overlay_color'] ) );
		update_post_meta( $post_id, 'hero_image_repeat', vidiho_pro_plugin_sanitize_image_repeat( $_POST['hero_image_repeat'] ) );
		update_post_meta( $post_id, 'hero_image_position_x', vidiho_pro_plugin_sanitize_image_position_x( $_POST['hero_image_position_x'] ) );
		update_post_meta( $post_id, 'hero_image_position_y', vidiho_pro_plugin_sanitize_image_position_y( $_POST['hero_image_position_y'] ) );
		update_post_meta( $post_id, 'hero_image_attachment', vidiho_pro_plugin_sanitize_image_attachment( $_POST['hero_image_attachment'] ) );
		update_post_meta( $post_id, 'hero_image_cover', isset( $_POST['hero_image_cover'] ) ? 1 : 0 );

		update_post_meta( $post_id, 'home_slider', isset( $_POST['home_slider'] ) ? 1 : 0 );

		vidiho_pro_plugin_sanitize_metabox_tab_sidebar( $post_id );
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_add_video_hero_meta_box' ) ) :
	function vidiho_pro_plugin_add_video_hero_meta_box( $object, $box ) {
		vidiho_pro_plugin_prepare_metabox( 'vidiho_pro_video' );

		?><div class="ci-cf-wrap"><?php

			vidiho_pro_plugin_metabox_open_tab( esc_html__( 'Video Details', 'vidiho-pro-plugin' ) );
				vidiho_pro_plugin_metabox_guide( __( 'Enter the URL of a YouTube or Vimeo video page. You may alternatively select or enter the URL to a self-hosted video file.', 'vidiho-pro-plugin' ) );
				?>
				<p class="ci-field-group ci-field-input">
					<?php vidiho_pro_plugin_metabox_input( 'vidiho_pro_video_url', esc_html__( 'Video URL:', 'vidiho-pro-plugin' ), array(
						'esc_func'    => 'esc_url',
						'input_class' => 'widefat ci-uploaded-url',
						'before'      => '',
						'after'       => '',
					) ); ?>
					<input type="button" class="button ci-media-button" value="<?php esc_attr_e( 'Select Video', 'vidiho-pro-plugin' ); ?>" />
				</p>
				<?php

				vidiho_pro_plugin_metabox_guide( __( "Set the image that will be displayed as the video's placeholder. This is strongly recommended, so if it's left empty, an image will be generated automatically for YouTube and Vimeo videos.", 'vidiho-pro-plugin' ) );

				$video_thumbnail_id = get_post_meta( $object->ID, 'vidiho_pro_video_thumbnail_id', true );
				?>
				<p>
				<div class="ci-upload-preview">
					<div class="upload-preview">
						<?php if ( ! empty( $video_thumbnail_id ) ): ?>
							<?php
								$image_url = wp_get_attachment_image_url( $video_thumbnail_id, 'vidiho_pro_plugin_featgal_small_thumb' );
								echo sprintf( '<img src="%s" /><a href="#" class="close media-modal-icon" title="%s"></a>',
									$image_url,
									esc_attr( __('Remove image', 'vidiho-pro-plugin') )
								);
							?>
						<?php endif; ?>
					</div>
					<input type="hidden" class="ci-uploaded-id" name="vidiho_pro_video_thumbnail_id" value="<?php echo esc_attr( $video_thumbnail_id ); ?>" />
					<input type="button" class="button ci-media-button" value="<?php esc_attr_e( 'Select Image', 'vidiho-pro' ); ?>" />
				</div>
				</p>
				<?php

				vidiho_pro_plugin_metabox_guide( __( 'Set your desired layout for the page. Video info includes: Title, categories, date.', 'vidiho-pro-plugin' ) );

				vidiho_pro_plugin_metabox_dropdown( 'vidiho_pro_video_layout', vidiho_pro_plugin_get_video_layout_choices(), esc_html__( 'Page layout:', 'vidiho-pro-plugin' ) );
			vidiho_pro_plugin_metabox_close_tab();


			$support = get_theme_support( 'vidiho-pro-hero' );
			$support = $support[0];

			vidiho_pro_plugin_metabox_open_tab( esc_html__( 'Hero section', 'vidiho-pro-plugin' ) );

				vidiho_pro_plugin_metabox_dropdown( 'hero_text_align', vidiho_pro_plugin_get_text_align_choices(), esc_html__( 'Title alignment:', 'vidiho-pro-plugin' ), array( 'default' => $support['text-align'] ) );

				?><p class="ci-field-group ci-field-input"><?php
					vidiho_pro_plugin_metabox_input( 'hero_bg_color', esc_html__( 'Background Color:', 'vidiho-pro-plugin' ), array( 'input_class' => 'vidiho-pro-color-picker widefat', 'before' => '', 'after' => '' ) );
				?></p><?php
				?><p class="ci-field-group ci-field-input"><?php
					vidiho_pro_plugin_metabox_input( 'hero_text_color', esc_html__( 'Text Color:', 'vidiho-pro-plugin' ), array( 'input_class' => 'vidiho-pro-color-picker widefat', 'before' => '', 'after' => '' ) );
				?></p><?php
				?><p class="ci-field-group ci-field-input"><?php
					vidiho_pro_plugin_metabox_input( 'hero_overlay_color', esc_html__( 'Overlay Color:', 'vidiho-pro-plugin' ), array( 'input_class' => 'vidiho-pro-alpha-color-picker widefat', 'before' => '', 'after' => '' ) );
				?></p><?php

				vidiho_pro_plugin_metabox_guide( array(
					wp_kses( __( 'The following image options are only applicable when a Hero image is selected.', 'vidiho-pro-plugin' ), vidiho_pro_plugin_get_allowed_tags( 'guide' ) ),
				) );

				$hero_image_id = get_post_meta( $object->ID, 'hero_image_id', true );
				?>
				<div class="ci-field-group ci-field-input">
					<label for="header_image_id"><?php esc_html_e( 'Hero image:', 'vidiho-pro-plugin' ); ?></label>
					<div class="ci-upload-preview">
						<div class="upload-preview">
							<?php if ( ! empty( $hero_image_id ) ) : ?>
								<?php
									$image_url = wp_get_attachment_image_url( $hero_image_id, 'vidiho_pro_plugin_featgal_small_thumb' );
									echo sprintf( '<img src="%s" /><a href="#" class="close media-modal-icon" title="%s"></a>',
										esc_url( $image_url ),
										esc_attr__( 'Remove image', 'vidiho-pro-plugin' )
									);
								?>
							<?php endif; ?>
						</div>
						<input name="hero_image_id" type="hidden" class="ci-uploaded-id" value="<?php echo esc_attr( $hero_image_id ); ?>" />
						<input id="hero_image_id" type="button" class="button ci-media-button" value="<?php esc_attr_e( 'Select Image', 'vidiho-pro-plugin' ); ?>" />
					</div>
				</div>
				<?php

				vidiho_pro_plugin_metabox_dropdown( 'hero_image_repeat', vidiho_pro_plugin_get_image_repeat_choices(), esc_html__( 'Image repeat:', 'vidiho-pro-plugin' ), array( 'default' => 'no-repeat' ) );
				vidiho_pro_plugin_metabox_dropdown( 'hero_image_position_x', vidiho_pro_plugin_get_image_position_x_choices(), esc_html__( 'Image horizontal position:', 'vidiho-pro-plugin' ), array( 'default' => 'center' ) );
				vidiho_pro_plugin_metabox_dropdown( 'hero_image_position_y', vidiho_pro_plugin_get_image_position_y_choices(), esc_html__( 'Image vertical position:', 'vidiho-pro-plugin' ), array( 'default' => 'center' ) );
				vidiho_pro_plugin_metabox_dropdown( 'hero_image_attachment', vidiho_pro_plugin_get_image_attachment_choices(), esc_html__( 'Image attachment:', 'vidiho-pro-plugin' ), array( 'default' => 'scroll' ) );
				vidiho_pro_plugin_metabox_checkbox( 'hero_image_cover', 1, esc_html__( 'Scale the image to cover its container.', 'vidiho-pro-plugin' ), array( 'default' => 1 ) );
				?><?php

			vidiho_pro_plugin_metabox_close_tab();

			vidiho_pro_plugin_metabox_open_tab( esc_html__( 'Homepage Slider', 'vidiho-pro-plugin' ) );
				vidiho_pro_plugin_metabox_checkbox( 'home_slider', 1, esc_html__( 'Show this post on the homepage slider.', 'vidiho-pro-plugin' ) );
			vidiho_pro_plugin_metabox_close_tab();

		?></div><?php
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_add_video_sidebar_meta_box' ) ) :
	function vidiho_pro_plugin_add_video_sidebar_meta_box( $object, $box ) {
		vidiho_pro_plugin_prepare_metabox( 'vidiho_pro_video' );

		?><div class="ci-cf-wrap"><?php

			vidiho_pro_plugin_print_metabox_tab_sidebar( $object, $box );

		?></div><?php
	}
endif;
