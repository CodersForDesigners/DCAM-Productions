<?php
add_action( 'admin_init', 'vidiho_pro_plugin_cpt_page_add_metaboxes' );
add_action( 'save_post', 'vidiho_pro_plugin_cpt_page_update_meta' );

if ( ! function_exists( 'vidiho_pro_plugin_cpt_page_add_metaboxes' ) ) :
	function vidiho_pro_plugin_cpt_page_add_metaboxes() {
		add_meta_box( 'vidiho-pro-plugin-hero', esc_html__( 'Hero section', 'vidiho-pro-plugin' ), 'vidiho_pro_plugin_add_page_hero_meta_box', 'page', 'normal', 'high' );
		add_meta_box( 'vidiho-pro-plugin-sidebar', esc_html__( 'Sidebar', 'vidiho-pro-plugin' ), 'vidiho_pro_plugin_add_page_sidebar_meta_box', 'page', 'side', 'low' );
		add_meta_box( 'vidiho-pro-plugin-tpl-video-listing', esc_html__( 'Video Listing Options', 'vidiho-pro-plugin' ), 'vidiho_pro_plugin_add_page_video_listing_meta_box', 'page', 'normal', 'high' );
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_cpt_page_update_meta' ) ) :
	function vidiho_pro_plugin_cpt_page_update_meta( $post_id ) {

		if ( ! vidiho_pro_plugin_can_save_meta( 'page' ) ) {
			return;
		}

		vidiho_pro_plugin_sanitize_metabox_tab_sub_title( $post_id );

		vidiho_pro_plugin_sanitize_metabox_tab_hero( $post_id );

		vidiho_pro_plugin_sanitize_metabox_tab_sidebar( $post_id );

		vidiho_pro_plugin_sanitize_metabox_tab_post_type_listing( 'vidiho_pro_video', $post_id );

	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_add_page_hero_meta_box' ) ) :
	function vidiho_pro_plugin_add_page_hero_meta_box( $object, $box ) {
		vidiho_pro_plugin_prepare_metabox( 'page' );

		?><div class="ci-cf-wrap"><?php

			vidiho_pro_plugin_print_metabox_tab_sub_title( $object, $box );

			vidiho_pro_plugin_print_metabox_tab_hero( $object, $box );

		?></div><?php
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_add_page_sidebar_meta_box' ) ) :
	function vidiho_pro_plugin_add_page_sidebar_meta_box( $object, $box ) {
		vidiho_pro_plugin_prepare_metabox( 'page' );

		?><div class="ci-cf-wrap"><?php

			vidiho_pro_plugin_print_metabox_tab_sidebar( $object, $box );

		?></div><?php

		vidiho_pro_plugin_bind_metabox_to_page_template( 'vidiho-pro-plugin-sidebar', 'default', 'vidiho_pro_sidebar_metabox_tpl' );
	}
endif;

if ( ! function_exists( 'vidiho_pro_plugin_add_page_video_listing_meta_box' ) ) :
	function vidiho_pro_plugin_add_page_video_listing_meta_box( $object, $box ) {
		vidiho_pro_plugin_prepare_metabox( 'page' );

		?><div class="ci-cf-wrap"><?php

			vidiho_pro_plugin_print_metabox_tab_post_type_listing( 'vidiho_pro_video', $object, $box, esc_html__( 'Video listing', 'vidiho-pro-plugin' ) );

		?></div><?php

		vidiho_pro_plugin_bind_metabox_to_page_template( 'vidiho-pro-plugin-tpl-video-listing', 'templates/listing-vidiho_pro_video.php', 'vidiho_pro_plugin_video_listing_metabox_tpl' );
	}
endif;
